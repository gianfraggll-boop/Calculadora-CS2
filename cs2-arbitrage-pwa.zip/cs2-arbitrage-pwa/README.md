# Calculadora Arbitraje CS2 — PWA

## Cómo instalar en 5 minutos (GitHub Pages)

### 1. Crear repositorio en GitHub
1. Ve a https://github.com/new
2. Ponle nombre: `cs2-arbitrage` (o el que quieras)
3. Márcalo como **Public**
4. Click en "Create repository"

### 2. Subir los archivos
1. En tu nuevo repositorio, click en "uploading an existing file"
2. Arrastra todos estos archivos y la carpeta `icons/`:
   - `index.html`
   - `manifest.json`
   - `sw.js`
   - `icons/icon-192.png`
   - `icons/icon-512.png`
3. Click en "Commit changes"

### 3. Activar GitHub Pages
1. Ve a Settings → Pages
2. En "Source" selecciona: **Deploy from a branch**
3. Branch: **main** → carpeta: **/ (root)**
4. Click "Save"
5. Espera 1-2 minutos

### 4. Instalar como PWA
1. Abre la URL que te da GitHub Pages (algo como `https://tuusuario.github.io/cs2-arbitrage`)
2. En Chrome, haz click en el ícono de instalar (⊕) en la barra de direcciones
3. Click "Instalar"
4. ¡Listo! Aparece en tu escritorio como una app

---
La app funciona 100% offline después de la primera carga.
